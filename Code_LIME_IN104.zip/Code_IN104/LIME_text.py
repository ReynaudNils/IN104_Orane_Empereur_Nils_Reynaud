## NOTE
"""Ce code à été réaliser sur un notebook (kaggle)"""

## CODE

#Importation des packages :

from sklearn.datasets import fetch_20newsgroups 
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import mean_absolute_error
from lime import lime_text
from sklearn.pipeline import make_pipeline
from lime.lime_text import LimeTextExplainer

#Determination des catégories du texte

Categories = ['chretien','athe', 'graphique']

nvgroupe_train = fetch_20newsgroups(subset='train')
nvgroupe_test = fetch_20newsgroups(subset='test')

#Definition des noms de classe en fonction des catégories :

nomclasse = ['Chretien', 'ATHE', 'graph']

vectorise = sklearn.feature_extraction.text.TfidfVectorizer(lowercase=False)
train_vecteurs = vectorise.fit_transform(nvgroupe_train.data)
test_vecteurs = vectorise.transform(nvgroupe_test.data)

df = RandomForestClassifier(n_estimators=500)
df.fit(train_vecteurs, nvgroupe_train.target)

pred = df.predict(test_vecteurs)
mean_absolute_error(nvgroupe_test.target, pred)
c = make_pipeline(vectorise, df)
nvgroupe_test.data[0]

explainer = LimeTextExplainer()
id_x = 10
exp = explainer.explain_instance(nvgroupe_test.data[id_x], c.predict_proba, num_features=6,top_labels=4)#generate an explanation with at most 6 features 
print('Document id: %d' % id_x)
print('Probability(atheism) =', c.predict_proba([nvgroupe_test.data[id_x]])[0,0])
print('Probability(christian) =', c.predict_proba([nvgroupe_test.data[id_x]])[0,1])
print('Probability(graphics) =', c.predict_proba([nvgroupe_test.data[id_x]])[0,2])

print('True class: %s' % nomclasse[nvgroupe_test.target[id_x]])
exp.as_list()#explaine

fig = exp.as_pyplot_figure()

exp.show_in_notebook(text=False)