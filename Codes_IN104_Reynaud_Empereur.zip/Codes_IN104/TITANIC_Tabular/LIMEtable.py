import pandas as pd                  #csv
import numpy as np
import matplotlib.pyplot as plt
import os
from sklearn.model_selection import train_test_split
import lime
import lime.lime_tabular
from sklearn.ensemble import RandomForestRegressor

#Pour ignorer les warnings
import warnings
warnings.filterwarnings('ignore')




#read data
dftrain = pd.read_csv('../input/titanic-survivor-test-and-train-datasets/train.csv')
dftest = pd.read_csv('../input/titanic-survivor-test-and-train-datasets/test.csv')
dftrain.head()
dftrain.info() #Pour voir les datas
dftest.head()
dftest.info()

dftrain.isnull().sum()   # Pour voir les valeurs manquantes"""
dftest.isnull().sum()

dftrain = dftrain.fillna(dftrain.mean()) #compléter valeurs manquantes
dftest = dftest.fillna(dftest.mean())

dftrain.isnull().sum()   # Pour vérifier que les data sont bien complètes
dftest.isnull().sum()

#On combine les deux dataset train et test

dftrain_dftest = [dftrain,dftest]

print(dftrain.columns.values)
#On regarde grace à des graphiques les données qui peuvent influer la survie d'un passager ou non

## NOTE
"""Ce code à été réaliser sur un Notebook (kaggle)"""

## CODE
def graph_baton(donnee):
    mort = dftrain[dftrain['Survived']==0][donnee].value_counts()
    """ value_counts() permet de compter le nombre de personne"""
    vivant = dftrain[dftrain['Survived']==1][donnee].value_counts()
    df = pd.DataFrame([vivant,mort])
    df.index = ['Vivant','Mort']
    df.plot(kind='bar',stacked=True, figsize=(10,5))
    plt.show()

# """graph_baton('Cabin')
# graph_baton('PassengerId')"""
# graph_baton('Pclass')
# """graph_baton('Name')"""
#graph_baton('Sex')
# graph_baton('Age')
# graph_baton('SibSp')
# graph_baton('Parch')
# """graph_baton('Ticket')"""
# """graph_baton('Fare')"""
# graph_baton('Embarked')

#Declaration des vecteurs, et de la variable visée (ici si passager on survécu 'Survived')
"""On change les données sur le sexe en entier"""
sex = {"male": 0, "female": 1}
for dataset in dftrain_dftest:
    dataset['Sex'] = dataset['Sex'].map(sex)
    


X=dftrain[['Pclass','Sex','Age','SibSp','Parch']]
Y=dftrain['Survived']



Xtrain, Xtest, Ytrain, Ytest = train_test_split(X, Y, test_size = 0.3, random_state = 0)

#Construction du model

model = RandomForestRegressor(max_depth=6, random_state=0, n_estimators=10)
model.fit(Xtrain, Ytrain)

#génération des prédiction

Predict = model.predict(Xtest)

explainer = lime.lime_tabular.LimeTabularExplainer(Xtrain.values, feature_names=Xtrain.columns.values.tolist(),
                                                  class_names=['Survived'], verbose=True, mode='regression')

j = 200
exp = explainer.explain_instance(Xtest.values[j], model.predict, num_features=6)

exp.show_in_notebook(show_table=True)

plt.show()
exp.as_list()