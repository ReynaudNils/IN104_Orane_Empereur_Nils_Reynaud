from IPython.display import display

import pandas as pd
from pdpbox import pdp, get_dataset, info_plots
import xgboost
from xgboost import XGBClassifier
import matplotlib
import matplotlib.pyplot as plt
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.datasets import make_hastie_10_2
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.inspection import partial_dependence
from sklearn.inspection import plot_partial_dependence
print(sklearn.__version__)
test_titanic = get_dataset.titanic()
print(test_titanic.keys())
titanic_data = test_titanic['data']
titanic_features = test_titanic['features']
titanic_model = test_titanic['xgb_model']
titanic_target = test_titanic['target']

print('Computing partial dependence plots...')
display = plot_partial_dependence(
       titanic_model, titanic_data, titanic_features, kind="both", subsample=50,
       n_jobs=3, grid_resolution=20, random_state=0
)
display.figure_.suptitle(
    'Partial dependence of house value on non-location features\n'
    'for the California housing dataset, with MLPRegressor'
)
display.figure_.subplots_adjust(hspace=0.3)